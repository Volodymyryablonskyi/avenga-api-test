package com.avenga.yablonskyi.dto;

public interface BasePojo {
}
