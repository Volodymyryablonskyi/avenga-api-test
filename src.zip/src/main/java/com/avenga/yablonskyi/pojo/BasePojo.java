package com.avenga.yablonskyi.pojo;

public interface BasePojo {
}
