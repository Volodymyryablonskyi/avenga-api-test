package com.avenga.yablonskyi.constants;

import com.avenga.yablonskyi.config.ApplicationConfig;

public class Constants {

    public static final String BASE_URI = ApplicationConfig.getBaseUri();

}
