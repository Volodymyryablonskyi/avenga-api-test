package com.avenga.yablonskyi.http.requests.enums;

public enum HttpMethod {
    GET, POST, PUT, DELETE
}
