package com.avenga.yablonskyi.util;

import io.qameta.allure.Attachment;

public class AllureAttachment {

    @Attachment(value = "{name}", type = "application/json", fileExtension = ".json")
    public static String attachJson(String name, String content) {
        return content;
    }

}